from gui.main_window import MainWindow # Importing MainWindow from gui.main_window

if __name__ == "__main__":
    app = MainWindow() # Cria a instância da janela principal
    app.mainloop() # Inicia o loop principal da aplicação
    
