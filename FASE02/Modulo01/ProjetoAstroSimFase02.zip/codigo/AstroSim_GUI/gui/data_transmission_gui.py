import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import json
from modules import compressaoHuffman as huff


class DataTransmissionGUI(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padding=10)
        self.pack(fill=tk.BOTH, expand=True)

        self.arvore_raiz = None

        # Título
        ttk.Label(self, text="Transmissão de Dados - Compressão Huffman",
                  font=("Segoe UI", 16, "bold")).pack(pady=(5, 15))

        # Notebook com abas
        notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True, padx=5)

        self._criar_abas(notebook)
        self._criar_botoes_principais()
        self._criar_botoes_arquivos()

    # === ABAS ===
    def _criar_abas(self, notebook):
        self._criar_aba_mensagem(notebook)
        self._criar_aba_codigos(notebook)
        self._criar_aba_arvore(notebook)
        self._criar_aba_entrada_manual(notebook)

    def _criar_aba_mensagem(self, notebook):
        aba = ttk.Frame(notebook)
        notebook.add(aba, text="Mensagem")

        self._criar_rotulo("Mensagem a ser comprimida:", aba)
        self.texto_original = self._criar_textbox(aba, height=4)

        self._criar_rotulo("Texto comprimido (binário):", aba)
        self.texto_comprimido = self._criar_textbox(aba, height=4)

        self._criar_rotulo("Texto descomprimido:", aba)
        self.texto_descomprimido = ttk.Label(aba, text="", wraplength=740,
                                             font=("Segoe UI", 10), bootstyle="light")
        self.texto_descomprimido.pack(pady=(0, 10), anchor='w', padx=5)

    def _criar_aba_codigos(self, notebook):
        aba = ttk.Frame(notebook)
        notebook.add(aba, text="Códigos Gerados")

        self._criar_rotulo("Códigos Huffman:", aba)
        self.codigos_texto = self._criar_textbox(aba, height=10)

    def _criar_aba_arvore(self, notebook):
        aba = ttk.Frame(notebook)
        notebook.add(aba, text="Árvore Huffman")

        self._criar_rotulo("Árvore de Huffman:", aba)
        self.arvore_texto = self._criar_textbox(aba, height=14)

    def _criar_aba_entrada_manual(self, notebook):
        aba = ttk.Frame(notebook)
        notebook.add(aba, text="Entrada Manual")

        self._criar_rotulo("Inserir códigos Huffman manualmente (ex: 'a' -> 01):", aba)
        self.codigos_personalizados = self._criar_textbox(aba, height=10)

    # === COMPONENTES ===
    def _criar_rotulo(self, texto, parent):
        ttk.Label(parent, text=texto, font=("Segoe UI", 10)).pack(anchor='w', pady=(10, 2), padx=5)

    def _criar_textbox(self, parent, height):
        caixa = ScrolledText(parent, height=height, width=90,
                             font=("Consolas", 10), wrap='none')
        caixa.pack(pady=(0, 10), padx=5, fill=tk.BOTH, expand=True)
        return caixa

    def _atualizar_textbox(self, caixa, texto):
        caixa.delete("1.0", tk.END)
        caixa.insert("1.0", texto)

    # === BOTÕES ===
    def _criar_botoes_principais(self):
        frame = ttk.Frame(self)
        frame.pack(pady=10)
        ttk.Button(frame, text="Comprimir", bootstyle="success", command=self.comprimir).pack(side=tk.LEFT, padx=10)
        ttk.Button(frame, text="Descomprimir", bootstyle="info", command=self.descomprimir).pack(side=tk.LEFT, padx=10)

    def _criar_botoes_arquivos(self):
        frame = ttk.Frame(self)
        frame.pack(pady=5)

        ttk.Button(frame, text="📂 Carregar Códigos de Arquivo", command=self.carregar_codigos_de_arquivo).pack(side=tk.LEFT, padx=10)
        ttk.Button(frame, text="💾 Salvar Códigos Gerados", command=self.salvar_codigos_gerados).pack(side=tk.LEFT, padx=10)
        ttk.Button(frame, text="💾 Salvar Árvore Huffman", command=self.salvar_arvore_huffman).pack(side=tk.LEFT, padx=10)

    # === FUNÇÕES PRINCIPAIS ===
    def comprimir(self):
        texto = self.texto_original.get("1.0", tk.END).strip()
        if not texto:
            self._atualizar_textbox(self.texto_comprimido, "[Erro] Mensagem vazia.")
            return

        binario, self.arvore_raiz = huff.codificar_huffman(texto)

        self._atualizar_textbox(self.texto_comprimido, binario)
        self._atualizar_textbox(self.codigos_texto, huff.imprimir_codigos(self.arvore_raiz))
        self._atualizar_textbox(self.arvore_texto, huff.imprimir_arvore(self.arvore_raiz))
        self.texto_descomprimido.config(text="")

    def descomprimir(self):
        binario = self.texto_comprimido.get("1.0", tk.END).strip()
        if not binario:
            self.texto_descomprimido.config(text="[Erro] Nenhum dado para descomprimir.")
            return

        arvore = self.arvore_raiz or self._reconstruir_arvore_dos_codigos(self._ler_codigos_personalizados())

        if arvore is None:
            self.texto_descomprimido.config(text="[Erro] Nenhuma árvore ou código válido disponível.")
            return

        try:
            texto = huff.decodificar_huffman(binario, arvore)
            self.texto_descomprimido.config(text=texto)
        except Exception as e:
            self.texto_descomprimido.config(text=f"[Erro ao decodificar]: {e}")

    # === MANIPULAÇÃO DE CÓDIGOS ===
    def _ler_codigos_personalizados(self):
        texto = self.codigos_personalizados.get("1.0", tk.END).strip()
        codigos = {}
        for linha in texto.splitlines():
            if '->' in linha:
                try:
                    caractere, codigo = linha.strip().split('->')
                    caractere = caractere.strip().strip("'").strip('"')
                    codigos[caractere] = codigo.strip()
                except Exception:
                    continue
        return codigos

    def _reconstruir_arvore_dos_codigos(self, codigos_dict):
        if not codigos_dict:
            return None
        raiz = huff.NoHuffman()
        for caractere, codigo in codigos_dict.items():
            no = raiz
            for bit in codigo:
                if bit == '0':
                    if not no.esquerda:
                        no.esquerda = huff.NoHuffman()
                    no = no.esquerda
                elif bit == '1':
                    if not no.direita:
                        no.direita = huff.NoHuffman()
                    no = no.direita
            no.caractere = caractere
        return raiz

    # === ARQUIVOS ===
    def carregar_codigos_de_arquivo(self):
        caminho = filedialog.askopenfilename(
            title="Selecionar arquivo de códigos",
            filetypes=[("Arquivos de texto", "*.txt"), ("Arquivos JSON", "*.json")]
        )
        if not caminho:
            return

        try:
            with open(caminho, 'r', encoding='utf-8') as f:
                if caminho.endswith('.json'):
                    codigos_dict = json.load(f)
                    texto = '\n'.join(f"'{k}' -> {v}" for k, v in codigos_dict.items())
                else:
                    texto = f.read()
            self._atualizar_textbox(self.codigos_personalizados, texto)
            messagebox.showinfo("Códigos carregados", "Códigos Huffman carregados com sucesso.")
        except Exception as e:
            messagebox.showerror("Erro ao carregar", f"Erro ao ler arquivo: {e}")

    def salvar_codigos_gerados(self):
        texto = self.codigos_texto.get("1.0", tk.END).strip()
        if not texto:
            messagebox.showwarning("Aviso", "Nenhum código gerado para salvar.")
            return

        caminho = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Arquivo texto", "*.txt")],
            title="Salvar códigos Huffman"
        )
        if caminho:
            with open(caminho, "w", encoding="utf-8") as f:
                f.write(texto)
            messagebox.showinfo("Sucesso", f"Códigos salvos em:\n{caminho}")

    def salvar_arvore_huffman(self):
        texto = self.arvore_texto.get("1.0", tk.END).strip()
        if not texto:
            messagebox.showwarning("Aviso", "Nenhuma árvore de Huffman gerada para salvar.")
            return

        caminho = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Arquivo texto", "*.txt")],
            title="Salvar árvore de Huffman"
        )
        if caminho:
            with open(caminho, "w", encoding="utf-8") as f:
                f.write(texto)
            messagebox.showinfo("Sucesso", f"Árvore salva em:\n{caminho}")
