import ttkbootstrap as tb
from ttkbootstrap.constants import *
from gui.mission_planner_gui import MissionPlannerGUI
from gui.inventory_gui import InventoryGUI
from gui.data_transmission_gui import DataTransmissionGUI
from gui.space_map_gui import SpaceMapGUI
from gui.resource_manager_gui import ResourceManagerGUI
from gui.science_analysis_gui import ScienceAnalysisGUI

class MainWindow(tb.Window):
    
    """Classe que representa a janela principal da aplicação AstroSim."""
    def __init__(self):
        super().__init__(themename="darkly")  # ⭐ Aplica o tema direto aqui
        self.title("AstroSim - Simulador de Missões Espaciais")
        self.geometry("1324x1324")

        self.create_widgets()

    def create_widgets(self):
        menu = tb.Notebook(self, bootstyle="primary")  # Estilo azul moderno
        menu.pack(fill="both", expand=True, padx=10, pady=10)

        menu.add(MissionPlannerGUI(menu), text="Planejamento de Missão")
        menu.add(InventoryGUI(menu), text="Inventário de Componentes")
        menu.add(DataTransmissionGUI(menu), text="Transmissão de Dados")
        menu.add(SpaceMapGUI(menu), text="Mapa Espacial")
        menu.add(ResourceManagerGUI(menu), text="Gerenciamento de Recursos")
        menu.add(ScienceAnalysisGUI(menu), text="Análise Científica")
