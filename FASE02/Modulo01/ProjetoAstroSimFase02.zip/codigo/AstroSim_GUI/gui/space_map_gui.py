import tkinter as tk
from tkinter import ttk # Importando ttk para widgets avançados

class SpaceMapGUI(ttk.Frame): # Classe para a GUI de Planejamento de Missões
    """Classe que representa a interface gráfica para o planejamento de missões espaciais.
    Esta classe herda de ttk.Frame e fornece uma interface para planejar missões com restrições, 
    utilizando programação inteira e heurísticas gulosas.
     """
    def __init__(self, parent):# Inicializa a classe com o pai como um widget ttk.Frame
        super().__init__(parent)#   Chama o construtor da classe pai

        ttk.Label(self, text="Mapa Espacial", font=("Arial", 14)).pack(pady=10)

        self.task_list = tk.Text(self, height=10, width=70)
        self.task_list.pack(pady=10)

        button_frame = ttk.Frame(self)
        button_frame.pack()

        ttk.Button(button_frame, text="Resolver com Programação Inteira", command=self.solve_exact).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Resolver com Heurística Gulosa", command=self.solve_greedy).pack(side=tk.LEFT, padx=5)

        self.result_label = ttk.Label(self, text="")
        self.result_label.pack(pady=10)

    def solve_exact(self):# Método para resolver o planejamento de missões com programação inteira
        self.result_label.config(text="Resultado (Exato): [A ser integrado com planner.py]")

    def solve_greedy(self):# Método para resolver o planejamento de missões com heurística gulosa
        self.result_label.config(text="Resultado (Guloso): [A ser integrado com planner.py]")
