import math

class Hashing:
    def __init__(self, tamanho=10, metodo_colisao='encadeamento', tipo_hash='divisao'):
        self.tamanho = tamanho
        self.tabela = [[] for _ in range(tamanho)] if metodo_colisao == 'encadeamento' else [None] * tamanho
        self.metodo_colisao = metodo_colisao
        self.tipo_hash = tipo_hash

    def calcular_hash(self, chave):
        if isinstance(chave, str):
            chave = self._converter_alfanumerica(chave)

        if self.tipo_hash == 'divisao':
            return chave % self.tamanho
        elif self.tipo_hash == 'multiplicacao':
            A = 0.6180339887  # constante irracional
            return int(self.tamanho * ((chave * A) % 1))
        elif self.tipo_hash == 'meio_quadrado':
            quadrado = chave * chave
            meio = int(str(quadrado)[len(str(quadrado))//2 - 1: len(str(quadrado))//2 + 1])
            return meio % self.tamanho
        elif self.tipo_hash == 'extracao':
            str_chave = str(chave)
            extraido = int(str_chave[1:3]) if len(str_chave) > 3 else chave
            return extraido % self.tamanho
        elif self.tipo_hash == 'raiz':
            raiz = int((chave ** 0.5) * 100)  # pega parte decimal
            return raiz % self.tamanho
        elif self.tipo_hash == 'xor':
            return self._xor_hash(str(chave)) % self.tamanho
        elif self.tipo_hash == 'rotacao':
            return self._rotacao_bits(str(chave)) % self.tamanho
        elif self.tipo_hash == 'peso':
            return self._peso_por_posicao(str(chave)) % self.tamanho
        else:
            raise ValueError("Tipo de hash desconhecido")

    def inserir(self, chave, valor):
        indice = self.calcular_hash(chave)
        if self.metodo_colisao == 'encadeamento':
            for par in self.tabela[indice]:
                if par[0] == chave:
                    par[1] = valor
                    return
            self.tabela[indice].append([chave, valor])
        else:  # endereçamento aberto (linear probing)
            original = indice
            while self.tabela[indice] is not None and self.tabela[indice][0] != chave:
                indice = (indice + 1) % self.tamanho
                if indice == original:
                    raise Exception("Tabela Hash cheia")
            self.tabela[indice] = [chave, valor]

    def buscar(self, chave):
        indice = self.calcular_hash(chave)
        if self.metodo_colisao == 'encadeamento':
            for par in self.tabela[indice]:
                if par[0] == chave:
                    return par[1]
            return None
        else:
            original = indice
            while self.tabela[indice] is not None:
                if self.tabela[indice][0] == chave:
                    return self.tabela[indice][1]
                indice = (indice + 1) % self.tamanho
                if indice == original:
                    break
            return None

    def remover(self, chave):
        indice = self.calcular_hash(chave)
        if self.metodo_colisao == 'encadeamento':
            for i, par in enumerate(self.tabela[indice]):
                if par[0] == chave:
                    del self.tabela[indice][i]
                    return True
        else:
            original = indice
            while self.tabela[indice] is not None:
                if self.tabela[indice][0] == chave:
                    self.tabela[indice] = None
                    return True
                indice = (indice + 1) % self.tamanho
                if indice == original:
                    break
        return False

    # =====================
    # Funções auxiliares
    # =====================
    def _converter_alfanumerica(self, chave_str):
        return sum(ord(c) for c in chave_str)

    def _xor_hash(self, chave_str):
        result = 0
        for c in chave_str:
            result ^= ord(c)
        return result

    def _rotacao_bits(self, chave_str):
        total = 0
        for i, c in enumerate(chave_str):
            valor = ord(c)
            rot = (valor << i) | (valor >> (8 - i))
            total += rot
        return total

    def _peso_por_posicao(self, chave_str):
        return sum((i+1) * ord(c) for i, c in enumerate(chave_str))

    def imprimir(self):
        for i, item in enumerate(self.tabela):
            print(f"{i}: {item}")