import mysql.connector

class Component:
    def __init__(self, cod_invent, nome, categoria, massa, consumo):
        self.cod_invent = cod_invent
        self.nome = nome
        self.categoria = categoria
        self.massa = massa
        self.consumo = consumo

    def __repr__(self):
        return f"{self.cod_invent} - {self.nome} ({self.categoria})"

# class InventoryManager:
#     def __init__(self):
#         self.conn = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="mysql",  # substitua pela sua senha
#             database="astrosim"
#         )
#         self.cursor = self.conn.cursor()

class LogMissao:
    def __init__(self, data, mensagem):
        self.data = data
        self.mensagem = mensagem

class InventoryManager:
    def __init__(self):
        import mysql.connector
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="mysql",  # Atualize conforme necessário
            database="astrosim"
        )
        self.cursor = self.conn.cursor()

    def add_component(self, component):
        sql = """
            INSERT INTO inventario_espacial (cod_invent, nome, categoria, massa, consumo)
            VALUES (%s, %s, %s, %s, %s)
        """
        dados = (
            component.cod_invent,
            component.nome,
            component.categoria,
            component.massa,
            component.consumo
        )
        self.cursor.execute(sql, dados)
        self.conn.commit()

    def get_all_components(self):
        self.cursor.execute("SELECT cod_invent, nome, categoria, massa, consumo FROM inventario_espacial")
        resultados = self.cursor.fetchall()
        return [Component(*linha) for linha in resultados]
    
    def get_all_logs(self):
        self.cursor.execute("SELECT data, mensagem FROM logs_missao")
        resultados = self.cursor.fetchall()
        return [LogMissao(data, mensagem) for data, mensagem in resultados]

    def close(self):
        self.cursor.close()
        self.conn.close()
