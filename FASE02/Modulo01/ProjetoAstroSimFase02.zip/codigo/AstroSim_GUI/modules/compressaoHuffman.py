import json

class NoHuffman:
    def __init__(self, caractere=None, frequencia=0):
        self.caractere = caractere
        self.frequencia = frequencia
        self.esquerda = None
        self.direita = None

    def eh_folha(self):
        return self.esquerda is None and self.direita is None


def codificar_huffman(texto):
    """Codifica o texto usando o algoritmo de Huffman e retorna o binário e a raiz da árvore."""
    frequencias = {}
    for c in texto:
        frequencias[c] = frequencias.get(c, 0) + 1

    arvores = [NoHuffman(c, f) for c, f in frequencias.items()]
    arvores.sort(key=lambda no: no.frequencia)

    while len(arvores) > 1:
        t1 = arvores.pop(0)
        t2 = arvores.pop(0)
        novo_no = NoHuffman(None, t1.frequencia + t2.frequencia)
        novo_no.esquerda = t1
        novo_no.direita = t2
        arvores.append(novo_no)
        arvores.sort(key=lambda no: no.frequencia)

    raiz = arvores[0]
    codigos = {}

    def gerar_codigos(no, caminho=""):
        if no is not None:
            if no.eh_folha():
                codigos[no.caractere] = caminho
            gerar_codigos(no.esquerda, caminho + "0")
            gerar_codigos(no.direita, caminho + "1")

    gerar_codigos(raiz)
    texto_codificado = ''.join(codigos[c] for c in texto)
    return texto_codificado, raiz


def decodificar_huffman(bits_codificados, arvore_raiz):
    """Decodifica uma sequência de bits usando a árvore de Huffman."""
    mensagem = ""
    no_atual = arvore_raiz

    for bit in bits_codificados:
        no_atual = no_atual.esquerda if bit == '0' else no_atual.direita
        if no_atual.eh_folha():
            mensagem += no_atual.caractere
            no_atual = arvore_raiz

    return mensagem


def imprimir_arvore(no, prefixo=""):
    """Gera uma representação textual da árvore de Huffman."""
    if no is None:
        return ""
    if no.eh_folha():
        linha = f"{prefixo}📄 '{no.caractere}' ({no.frequencia})\n"
    else:
        linha = f"{prefixo}🌿 [Interno] ({no.frequencia})\n"
    return linha + imprimir_arvore(no.esquerda, prefixo + "  ") + imprimir_arvore(no.direita, prefixo + "  ")


def imprimir_codigos(no, caminho=""):
    """Gera uma string com os códigos Huffman de cada caractere."""
    if no is None:
        return ""
    if no.eh_folha():
        return f"'{no.caractere}' -> {caminho} (freq: {no.frequencia})\n"
    return imprimir_codigos(no.esquerda, caminho + "0") + imprimir_codigos(no.direita, caminho + "1")


def serializar_arvore(no):
    """Serializa a árvore de Huffman para JSON (como dicionário)."""
    if no is None:
        return None
    return {
        'caractere': no.caractere,
        'frequencia': no.frequencia,
        'esquerda': serializar_arvore(no.esquerda),
        'direita': serializar_arvore(no.direita)
    }


def desserializar_arvore(data):
    """Reconstrói a árvore de Huffman a partir de um dicionário JSON."""
    if data is None:
        return None
    no = NoHuffman(data['caractere'], data['frequencia'])
    no.esquerda = desserializar_arvore(data['esquerda'])
    no.direita = desserializar_arvore(data['direita'])
    return no
